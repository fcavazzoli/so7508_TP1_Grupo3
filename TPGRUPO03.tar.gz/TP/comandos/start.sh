
logger(){
	sh logger/logger.sh "$1" "$2" "start.sh"
}

PSAG="$(ps ag)"
PROC=$(echo "$PSAG" | grep "sh process.sh" | sed "s/^ *//" | cut -d" " -f1)

if [ ! -z $PROC ]; then
	logger "El proceso ya esta corriendo: PID: $PROC" "A"
	logger "Saliendo de proceso start" "I"
	exit
fi

if [ -z "$HEALTHY_ENV" ] || [ "$HEALTHY_ENV" -eq 0 ]; then


	logger "El ambiente no se encuentra inicializado correctamente" "A"
	logger "Inicialice el ambiente y luego vuelva a intentar" "A"
	logger "Saliendo de proceso start" "I"
	exit
fi

logger "Se procederá a iniciar el proceso " "I"
sh process.sh &
