logger(){
	sh logger/logger.sh "$1" "$2" "stop.sh"
}


matarProceso() 
{
	logger "Se buscará un proceso iniciado por sh process.sh" "I"

    PSAG="$(ps ag)"
	PROC=$(echo "$PSAG" | grep 'process.sh' | sed "s/^ *//" | cut -d" " -f1)

	if [ -z $PROC ]; then
	  logger "No se encontraron procesos iniciados por sh process.sh" "I"
	  logger "El proceso no se estaba ejecutando" "I"
	  exit
	elif [ $PROC -eq 0 ]; then
	  sh shell/log.sh "No se encuentra corriendo el proceso" "E"
	  exit
	else
	  logger "Se encontró el proceso $PROC iniciado por sh process.sh" "A"
	  logger "Se procederá a matar el proceso $PROC" "A"
	  kill $PROC
	  logger "Se ha matado el proceso $PROC"
	fi
}

logger "Se comienza con el detenimiento del proceso." "I"
FILE_RUN="../conf/running_process.txt"

if [ ! -e "$FILE_RUN" ]; then
	logger "No se encontro archivo conf/running_process.txt" "I"
	matarProceso
else
	logger "Se ha encontrado archivo conf/running_process.txt" "I"
	LINE=$(grep -r "RUNNING" "$FILE_RUN" | cut -d"=" -f2)
	if [ $LINE=1 ]; then
		CHANGE=$(grep -r "RUNNING" "$FILE_RUN" | cut -d"=" -f2 | sed -i "s/1/0/g" "$FILE_RUN")
		logger "Se ha modificado el parametro del proceso para detenerlo" "I"
	elif [ $LINE=0 ] ; then
		logger "El archivo conf/running_process.txt indica que el proceso no se hallaba corriendo" "I"
		matarProceso
	else
		logger "El archivo encontrado conf/running_process.txt no tenía información" "I"
		matarProceso
	fi
fi

logger "Se sale del proceso stop.sh" "I"

exit
