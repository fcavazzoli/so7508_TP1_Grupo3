logger()
{
  sh logger/logger.sh "$1" "$2" "init.sh"
}

HEALTHY_ENV=1
if [ ! -d "../conf" ]; then
  echo "No existe el directorio reservado 'conf'."
  HEALTHY_ENV=0
fi

if [ ! -f "../conf/tpconfig.txt" ]; then
  echo "No existe el archivo de configuracion 'tpconfig.txt'."
  HEALTHY_ENV=0
fi


# Se setean las variables de entorno
while IFS= read -r var
do
  VARIABLE=$(echo $var | cut -d"-" -f1)
  VALUE=$(echo $var | cut -d"-" -f2)

  # Me fijo si el directorio existe (pagina 6)
  if [ ! -d "$VALUE" ]; then
    echo "El directorio $VALUE no existe."
    HEALTHY_ENV=0
  fi
  echo "Seteo variables $VARIABLE = $VALUE" 
  export "$VARIABLE"="$VALUE"

done < "../conf/tpconfig.txt"

if [ ! -z "$MASTER_DIR" ]; then
  if [ ! -f "$MASTER_DIR/CODIGOSISO8583.txt" ]; then
    echo "No existe el archivo maestro de 'CODIGOSISO8583.txt'."
    HEALTHY_ENV=0
  fi
fi

if [ ! -f "logger/logger.sh" ]; then
  echo "No se encuentra la libreria de log."
  HEALTHY_ENV=0
fi

if [ $HEALTHY_ENV -eq 0 ]; then
  echo "No se puede inicializar el sistema." "E"
  echo "Debe reinstalar la aplicacion ejecutando el comando: " "I"
  echo "  sh install.sh -r" "I"
  exit
fi

# Inicio el proceso de Inicializacion
logger "Proceso de Inicializacion" "I"

# Obtengo la lista de procesos para saber si ya esta corriendo
PSAG="$(ps ag)"
RUNNING_PROCESSES=$(echo "$PSAG" | grep -c 'process.sh')

logger "Cantidad de procesos corriendo $RUNNING_PROCESSES" "I"

export HEALTHY_ENV="$HEALTHY_ENV"

if [ $RUNNING_PROCESSES -eq 0 ]; then    
    logger "El proceso NO esta corriendo." "I"
    . ./start.sh    
else
    logger "El proceso ya se encuentra corriendo." "A"
fi

logger "Saliendo del proceso init.sh" "I"

