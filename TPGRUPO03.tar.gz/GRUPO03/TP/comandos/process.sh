logger() 
{
    sh logger/logger.sh "$1" "$2" "process.sh"
}



iniciadoCorrectamente(){
  
  must_exit=0
  if [ -z "$CONF_DIR" ]; then  
    logger "Falta inicializar: no se encontró la variable CONF_DIR." "E"
    must_exit=1
  fi
  if [ -z "$LOG_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable LOG_DIR." "E"
    must_exit=1
  fi
  if [ -z "$MASTER_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable MASTER_DIR." "E"
    must_exit=1
  fi
  if [ -z "$ARRIVALS_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable ARRIVALS_DIR." "E"
    must_exit=1
  fi
  if [ -z "$ACCEPTED_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable ACCEPTED_DIR." "E"
    must_exit=1
  fi
  if [ -z "$REJECTED_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable REJECTED_DIR." "E"
    must_exit=1
  fi
  if [ -z "$PROCESSED_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable PROCESSED_DIR." "E"
    must_exit=1
  fi
  if [ -z "$OUTPUT_DIR" ]; then
    logger "Falta inicializar: no se encontró la variable OUTPUT_DIR." "E"
    must_exit=1 
  fi

  if [ ! -e "$MASTER_DIR/CODIGOSISO8583.txt" ] ; then
    logger "No se encuentra el archivo maestro de CODIGOS ISO " "E"
    must_exit=1
  fi 
  if [ $must_exit -eq 1 ] ; then 
    logger "No podemos seguir con el proceso" "E"
    logger "Saliendo del proceso" "A"
    exit
  fi
}
rechazarNovedad()
{  
  FILENAME_R=$(basename "$1")
  FILEPATH_R="$REJECTED_DIR/$FILENAME_R"

  mv "$1" "$FILEPATH_R"
}


procesarCierre(){
  
  trailer_reg="$1"

  LOTE="$2"
 					    
  FORMATO_CORRECTO="$(echo "$trailer_reg" |  sed "s/^\([^;]*;\)\{17\}\([^;]*\)//")"

  if [ ! -z "$FORMATO_CORRECTO" ] ; then
	logger "Registro con formato incorrecto en Lote_$LOTE" "A"
	echo "$trailer_reg" >> "$OUTPUT_DIR/BAD_FORMAT_LOTE_$LOTE"	
	logger "Se coloco el registro en $OUTPUT_DIR/BAD_FORMAT_LOTE_$LOTE" "A"
	return 0
  fi
	


  TRAILER_OPCODE="$(echo "$trailer_reg" | cut -d";" -f1)"
  TRAILER_DESC="$(echo "$trailer_reg" | cut -d";" -f2)"
  TOTAL_TRX="$(echo "$trailer_reg" | cut -d";" -f3 )"
  TRAILER_CLOSE="$(echo "$trailer_reg" | cut -d";" -f4)"
  TRAILER_YEAR="$(echo "$trailer_reg" | cut -d";" -f5 )"
  TRAILER_DATETIME="$(echo "$trailer_reg" | cut -d";" -f6)"
  TRAILER_TRACE="$(echo "$trailer_reg" | cut -d";" -f11)"
  TRAILER_ISOCODE="$(echo "$trailer_reg" | cut -d";" -f12 )"
  TRAILER_ISOCODE_AUX="$(echo "$trailer_reg" | cut -d";" -f12)"
  TRAILER_RRN="$(echo "$trailer_reg" | cut -d";" -f13 )"
  TRAILER_HOST_MSG="$(echo "$trailer_reg" | cut -d";" -f18 )"

  if [ -z "$TRAILER_HOST_MSG" ] || [ "$TRAILER_HOST_MSG" = " " ] ; then
    TRAILER_HOST_MSG="$(grep "^$TRAILER_ISOCODE_AUX;" "$MASTER_DIR"/CODIGOSISO8583.txt | sed "s/\([0-9]\{2\};\)//" | sed "s/;/- /")"
    if [ -z "$TRX_HOST_MSG" ] || [ "$TRX_HOST_MSG" = " " ] ; then
    	TRX_HOST_MSG="RECHAZADA - Denegada, codigo inexistente, o no contemplado en la tabla"
    fi  
  fi


  TRAILER_BATCH="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{3\}\)\(.*\)/\1/" )"

  TRAILER_NUM_COMPRAS="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{3\}\)\([0-9]\{4\}\)\(.*\)/\2/" )"

  TRAILER_MONTO_COMPRAS="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{7\}\)\([0-9]\{12\}\)\(.*\)/\2/" | sed "s/\(^0*\)\([1-9][0-9]*\)*\([0-9]\)\([0-9]\{2\}\)/\2\3.\4/")"

  TRAILER_NUM_DEV="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{19\}\)\([0-9]\{4\}\)\(.*\)/\2/" )"

  TRAILER_MONTO_DEV="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{23\}\)\([0-9]\{12\}\)\(.*\)/\2/" | sed "s/\(^0*\)\([1-9][0-9]*\)*\([0-9]\)\([0-9]\{2\}\)/\2\3.\4/")"

  TRAILER_NUM_NUL="$(echo "$trailer_reg"  | cut -d";" -f18 | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{35\}\)\([0-9]\{4\}\)\(.*\)/\2/" )"

  TRAILER_AMOUNT_NUL="$(echo "$trailer_reg" | cut -d";" -f18  | sed "s/\([0-9]*-->\)//" | sed "s/\(^[0-9]\{39\}\)\([0-9]\{12\}\)\(.*\)/\2/" | sed "s/\(^0*\)\([1-9][0-9]*\)*\([0-9]\)\([0-9]\{2\}\)/\2\3.\4/" )"

  OUTPUT_REG="$TRAILER_OPCODE;$TRAILER_DESC;$TOTAL_TRX;$TRAILER_CLOSE;$TRAILER_YEAR;$TRAILER_DATETIME;$TRAILER_TRACE;$TRAILER_ISOCODE;$TRAILER_RRN;$TRAILER_HOST_MSG;$TRAILER_BATCH;$TRAILER_NUM_COMPRAS;$TRAILER_MONTO_COMPRAS;$TRAILER_NUM_DEV;$TRAILER_MONTO_DEV;$TRAILER_NUM_NUL;$TRAILER_AMOUNT_NUL"
  OUTPUT_FILE="$OUTPUT_DIR/Cierre_De_Lote"

  echo "$OUTPUT_REG" >> "$OUTPUT_FILE"

  return 0

}
procesarTRX()
{     
  trx="$1"

  LOTE="$2"

  FORMATO_CORRECTO="$(echo "$trx" | sed "s/^\([^;]*;\)\{17\}\([^;]*\)//")"

  if [ ! -z "$FORMATO_CORRECTO" ] ; then
	logger "Registro con formato incorrecto en Lote_$LOTE" "A"
	echo "$trx" >> "$OUTPUT_DIR/BAD_FORMAT_LOTE_$LOTE"
	logger "Se coloco el registro en $OUTPUT_DIR/BAD_FORMAT_LOTE_$LOTE" "A"	
	return 0
  fi
	

  TRX_OPCODE="$(echo $trx | cut -d";" -f1)"


  if [ "$TRX_OPCODE" = "CI" ] ; then 
    procesarCierre "$trx" "$LOTE"
    return $?
  fi


  TRX_DESC="$(echo "$trx" | cut -d";" -f2 )"
  TRX_YEAR="$(echo "$trx" | cut -d";" -f5 )"
  TRX_DATETIME="$(echo "$trx" | cut -d";" -f6 )"
  TRX_CARD="$(echo "$trx" | cut -d";" -f7 )"
  TRX_DUEDATE="$(echo "$trx" | cut -d";" -f8 )"
  TRX_AMOUNT="$(echo "$trx" | cut -d";" -f9 )"
  TRX_CUOTA="$(echo "$trx" | cut -d";" -f10 )"
  TRX_TRACE="$(echo "$trx" | cut -d";" -f11 )"
  TRX_ISOCODE_AUX="$(echo "$trx" | cut -d";" -f12  | sed "s/\([0-9]*-->\)//")"
  TRX_ISOCODE="$(echo "$trx" | cut -d";" -f12 )"
  TRX_RRN="$(echo "$trx" | cut -d";" -f13 )"
  TRX_TICKETNUM="$(echo "$trx" | cut -d";" -f14 )"
  TRX_AUTH="$(echo "$trx" | cut -d";" -f15 )"
  TRX_ID="$(echo "$trx" | cut -d";" -f16 )"
  TRX_RELATED="$(echo "$trx" | cut -d";" -f17 )"
  TRX_HOST_MSG="$(echo "$trx" | cut -d";" -f18 )"

  if [ -z "$TRX_HOST_MSG" ] || [ "$TRX_HOST_MSG" = " " ] ; then
    TRX_HOST_MSG="$(grep "^$TRX_ISOCODE_AUX;" "$MASTER_DIR"/CODIGOSISO8583.txt | sed "s/\([0-9]\{2\};\)//" | sed "s/;/- /")"
    if [ -z "$TRX_HOST_MSG" ] || [ "$TRX_HOST_MSG" = " " ] ; then
    	TRX_HOST_MSG="RECHAZADA - Denegada, codigo inexistente, o no contemplado en la tabla"
    fi  
  fi 

  TRX_MONTH="$(echo "$TRX_DATETIME" | sed "s/\([0-9]*-->\)//" | sed "s/\([0-9]\{2\}\)\([0-9]\{2\}\)\([0-9]\{6\}\)/\1/" )"
  TRX_DAY="$(echo "$TRX_DATETIME" | sed "s/\([0-9]*-->\)//" | sed "s/\([0-9]\{2\}\)\([0-9]\{2\}\)\([0-9]\{6\}\)/\2/" )"
  TRX_TIME="$(echo "$TRX_DATETIME" | sed "s/\([0-9]*-->\)//" | sed "s/\([0-9]\{2\}\)\([0-9]\{2\}\)\([0-9]\{6\}\)/\3/" | sed "s/\([0-9]\{2\}\)\([0-9]\{2\}\)\([0-9]\{2\}\)/\1:\2:\3/" )"

  TRX_MONEY="$(echo "$TRX_AMOUNT" | sed "s/\(^0*\)\([1-9][0-9]*\)*\([0-9]\)\([0-9]\{2\}\)/\2\3.\4/")"

  OUTPUT_REG="$TRX_OPCODE;$TRX_DESC;$TRX_YEAR;$TRX_DATETIME;$TRX_CARD;$TRX_DUEDATE;$TRX_AMOUNT;$TRX_CUOTA;$TRX_TRACE;$TRX_ISOCODE;$TRX_RRN;$TRX_TICKETNUM;$TRX_AUTH;$TRX_ID;$TRX_RELATED;$TRX_HOST_MSG;$TRX_MONTH;$TRX_DAY;$TRX_TIME;$TRX_AMOUNT"

  AUX_YEAR="$(echo "$trx" | cut -d";" -f5 | sed "s/\([0-9]*-->\)//")"

  OUTPUT_FILE="$OUTPUT_DIR/TRX-$AUX_YEAR$TRX_MONTH$TRX_DAY"

  if [ -z "$AUX_YEAR" ] || [ -z "$TRX_MONTH" ] || [ -z "$TRX_DAY" ] ; then
	OUTPUT_FILE="$OUTPUT_DIR/UNDATED_LOTE_$LOTE"
  fi
  echo "$OUTPUT_REG" >> "$OUTPUT_FILE"

  return 0

}




processFile() 
{  
  FILENAME=$(basename "$1")
  logger "Comienza archivo de novedades: $FILENAME" "I"

  CORRECT_FORMAT=$(echo $FILENAME | grep "Lote\_[0-9]\{2\}" -c) 
  numDeLote=$(echo $FILENAME | cut -d"_" -f2)

  if [ $CORRECT_FORMAT -eq 0 ] || [ $numDeLote -lt 1 ] || [ $numDeLote -gt 99 ] ; then
    logger "El archivo $FILENAME fue rechazado. Causa: Nombre inválido." "E"
    rechazarNovedad "$1"
    return 1
  fi

  if [ ! -f "$1" ]; then
    logger "El archivo $FILENAME fue rechazado. Causa: no es regular." "A"
    rechazarNovedad "$1"
    return 1
  fi

  if [ ! -s "$1" ]; then
    logger "El archivo $FILENAME fue rechazado. Causa: está vacío." "A"
    rechazarNovedad "$1"
    return 1
  fi

  REPEATED=$(ls -1 "$PROCESSED_DIR" | grep "$FILENAME" -c)
  
  if [ $REPEATED -gt 0 ]; then
    logger "El archivo $FILENAME fue rechazado. Causa: archivo repetido." "A"
    rechazarNovedad "$1"
    return 1
  fi

  FILEPATH="$ACCEPTED_DIR/$FILENAME"

  mv "$1" "$FILEPATH"

  logger "El archivo $FILENAME fue aceptado." "I"
  logger "Se ha movido el archivo $FILENAME desde $ARRIVALS_DIR hacia $ACCEPTED_DIR" "I"

  LAST=$(grep . "$FILEPATH" | tail -n1)
  TRAILER_CODE=$(echo $LAST | cut -d";" -f1 | sed "s/ *$//" | sed "s/^ *//")
 
  if [ ! "$TRAILER_CODE" = "CI" ]; then

    logger "El último registro del lote: $FILENAME no corresponde a un cierre de lote." "E"
    logger "Se rechaza por completo el archivo $FILENAME, previamente aceptado"
    logger "Se moverá el archivo $FILENAME a $REJECTED_DIR" "I"
    rechazarNovedad "$FILEPATH"

    return 1
  fi

  TRX_NUM_CIERRE=$(echo "$LAST" | cut -d";" -f3 | sed "s/ *$//" | sed "s/^ *//")
   
  logger "Numero de transacciones indicadas en el cierre del lote: $TRX_NUM_CIERRE" "I"

  REG_NUM=$(grep . "$FILEPATH" -c)
  TRX_NUM_REAL=$(expr $REG_NUM - 1)

  logger "Cantidad de transacciones existentes en el archivo: $TRX_NUM_REAL" "I"

  if [ ! $TRX_NUM_REAL -eq $TRX_NUM_CIERRE ]; then

    logger "Trx indicadas en el cierre: ($TRX_NUM_CIERRE) no se coresponde con la cantidad real de trx: $TRX_NUM_REAL" "E"

    rechazarNovedad $FILEPATH
    return 1        

  fi
  
  logger "El registro trailer se encuentra OK." "I"

  while IFS2= read -r line
  do

    procesarTRX "$line" "$numDeLote"

  done < "$FILEPATH"

  procesarCierre "$LAST" "$numDeLote"

  mv "$FILEPATH" "$PROCESSED_DIR/$FILENAME"

  return 0
  
}

fueDetenidoPorStop()
{
  RUN_CONTROL_FILE="../conf/running_process.txt"
  
  if [ ! -e $RUN_CONTROL_FILE ]; then
    echo "RUNNING=1" >> $RUN_CONTROL_FILE
    logger "El proceso esta corriendo" "I"
    RETVAL=1
  else
    EXISTED=$(grep -r "RUNNING" "$RUN_CONTROL_FILE") 
    if [ ! -z $EXISTED ]
    then
      LINE=$(grep -r "RUNNING" "$RUN_CONTROL_FILE" | cut -d"=" -f2)
      #si se para el proceso
      if [ $LINE -eq 0 ]; then
        logger "El proceso fue detenido" "A"
        RETVAL=0
      else
        RETVAL=1  
      fi
    else
      RETVAL=1
    fi
  fi
  return "$RETVAL"
}

CYCLE=1


iniciadoCorrectamente

RUN_CONTROL_FILE="../conf/running_process.txt"
if [ ! -e $RUN_CONTROL_FILE ]; then
  echo "RUNNING=1" >> $RUN_CONTROL_FILE
  logger "Ha comenzado el proceso" "I"
else
  VALUE_RUN=$(grep -r "RUNNING" "$RUN_CONTROL_FILE")
  if [ ! -z $VALUE_RUN ] ; then
    LINE=$(grep -r "RUNNING" "$RUN_CONTROL_FILE" | cut -d"=" -f2)
    if [ $LINE -eq 1 ]; then
      logger "El procesamiento ya estaba en marcha." "A"
    else
      CHANGE=$(grep -r "RUNNING" "$RUN_CONTROL_FILE" | cut -d"=" -f2 | sed -i "s/0/1/g" "$RUN_CONTROL_FILE")
      logger "El proceso ha comenzado a correr" "I"
    fi
  else
      logger "El proceso ha comenzado a correr" "I"
  fi  
fi

# Demonio!
# Bucle sin fin
while [ 1 -eq 1 ]; do
  logger "Inicio ciclo de procesamiento número: $CYCLE" "I"
  iniciadoCorrectamente
  ls -1 "$ARRIVALS_DIR" | while IFS= read -r file
  do
    processFile "$ARRIVALS_DIR/$file"    
  done

  logger "Fin de ciclo de procesamiento número: $CYCLE" "I"

  CYCLE=$(expr $CYCLE + 1)
  
  # Se espera un minuto
  CYCLE_WAIT=0
  while [ $CYCLE_WAIT -lt 60 ]; do
    fueDetenidoPorStop
    STOPPED=$?

    if [ $STOPPED -eq 0 ]; then
      logger "Terminando proceso" "I"
      exit 0
    fi

    sleep 1
    CYCLE_WAIT=$(expr $CYCLE_WAIT + 1)  
  done    
done  

exit
