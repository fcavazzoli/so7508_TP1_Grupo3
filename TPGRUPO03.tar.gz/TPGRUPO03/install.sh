
#!/bin/sh


NUM_ARGS="$#"
OPCION="$1"
GRUPO=$PWD
DIR_BINARIOS=$GRUPO/bin
DIR_MAESTROS=$GRUPO/maestros
DIR_ARRIBO_NOVEDADES=$GRUPO/novedades
DIRNOVEDADESACEPTADAS=$GRUPO/aceptados
DIR_RECHAZADOS=$GRUPO/rechazados
DIR_PROCESADOS=$GRUPO/procesados
DIR_SALIDA=$GRUPO/salida


CURRENT_DATE=$(date +"%Y%m%d%H%M%S")

InstallLog() {

    MESSAGE=$1
    TYPE=$2

    if [ "$TYPE" = "I" ]; then
    TYPE="INFO"
    elif [ "$TYPE" = "A" ]; then
    TYPE="ATENCION"
    else
    TYPE="ERROR"
    fi

    format_date=$(date +"%Y%m%d")

    MESSAGE=$format_date-$USER-install.sh-$TYPE-$MESSAGE

    # Como esta ruta
    if [ ! -e "$GRUPO/conf/log" ] ; then
        mkdir "$GRUPO/conf/log"
    fi

    echo $MESSAGE
    echo $MESSAGE >> "./conf/log/instalacion.log"
}

escribirTPconfig(){

	touch "$GRUPO/conf/tpconfig.txt"
	
	
	InstallLog "Se ha creado el archivo tpconfig.txt" "I"
	InstallLog "Se agregan los valores al archivo tpconfig.txt" "I"
	echo "FATHER_DIR-$GRUPO" >> $GRUPO/conf/tpconfig.txt
	echo "ACCEPTED_DIR-$DIRNOVEDADESACEPTADAS" >> $GRUPO/conf/tpconfig.txt
	echo "CONF_DIR-$GRUPO/conf" >> $GRUPO/conf/tpconfig.txt
	echo "ARRIVALS_DIR-$DIR_ARRIBO_NOVEDADES" >> $GRUPO/conf/tpconfig.txt
	echo "LOG_DIR-$GRUPO/conf/log" >> $GRUPO/conf/tpconfig.txt
	echo "MASTER_DIR-$DIR_MAESTROS" >> $GRUPO/conf/tpconfig.txt
	echo "OUTPUT_DIR-$DIR_SALIDA" >> $GRUPO/conf/tpconfig.txt
	echo "REJECTED_DIR-$DIR_RECHAZADOS" >> $GRUPO/conf/tpconfig.txt
	echo "PROCESSED_DIR-$DIR_PROCESADOS" >> $GRUPO/conf/tpconfig.txt
	echo "BIN_DIR-$DIR_BINARIOS" >> $GRUPO/conf/tpconfig.txt
	
	InstallLog "tpconfig: CONF_DIR-$GRUPO/conf" "I"
	InstallLog "tpconfig: LOG_DIR-$GRUPO/conf/log" "I"
	InstallLog "tpconfig: MASTER_DIR-$DIR_MAESTROS" "I"
	InstallLog "tpconfig: ARRIVALS_DIR-$DIR_ARRIBO_NOVEDADES" "I"
	InstallLog "tpconfig: ACCEPTED_DIR-$DIRNOVEDADESACEPTADAS" "I"
	InstallLog "tpconfig: REJECTED_DIR-$DIR_RECHAZADOS" "I"
	InstallLog "tpconfig: PROCESSED_DIR-$DIR_PROCESADOS" "I"
	InstallLog "tpconfig: OUTPUT_DIR-$DIR_SALIDA" "I"
	InstallLog "tpconfig: BIN_DIR-$DIR_BINARIOS" "I"

}

listarDirectorios(){
	InstallLog "TP SO7508 Segundo Cuatrimestre 2019 Copyright © Grupo 03 " "I"
	InstallLog "Directorio padre $GRUPO" "I"
	InstallLog "Directorio de archivos de configuración: $GRUPO/conf" "I"
	InstallLog "Directorio de archivos de log: $GRUPO/conf/log" "I"
	InstallLog "Directorio de ejecutables: $DIR_BINARIOS" "I"
	InstallLog "Directorio de archivos maestros: $DIR_MAESTROS" "I"
	InstallLog "Directorio de novedades: $DIR_ARRIBO_NOVEDADES" "I"
	InstallLog "Directorio de novedades aceptadas: $DIRNOVEDADESACEPTADAS" "I"
	InstallLog "Directorio de novedades rechazadas: $DIR_RECHAZADOS" "I"
	InstallLog "Directorio de novedades procesadas: $DIR_PROCESADOS" "I"
	InstallLog "Directorio con output: $DIR_SALIDA" "I"
}



verificarNombres(){
    res=1
    salir=0
    while [ $salir = 0 ] ; do
        read nombre
        if [ -z "$nombre" ] ; then
			InstallLog "Se ha ingresado un nombre vacío" "I"
            InstallLog "Se mantiene el nombre por defecto" "I"
            default=1
        else
			InstallLog "Nombre ingresado:$nombre" "I"
		fi

        CHAR_INVALIDO=$(echo "$nombre" | grep "[*~/\]" -c)
        if [ "$CHAR_INVALIDO" -gt 0 ] ;  then  
            InstallLog "No se permiten los caracteres *~/\ para el nombre del directorio" "I"
            InstallLog "Ingrese otro nombre:" "I"
            res=0
        else 
            if [ "$GRUPO/$nombre" = "$GRUPO/conf" ] ; then 
                InstallLog "Nombre reservado por el sistema. Ingrese otro." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIREORIGINAL" ] ; then 
                InstallLog "Nombre reservado por el sistema. Ingrese otro" "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_BINARIOS" ] && [ $numeroComparacion != 1 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_MAESTROS" ] && [ $numeroComparacion != 2 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_ARRIBO_NOVEDADES" ] && [ $numeroComparacion != 3 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIRNOVEDADESACEPTADAS" ]  && [ $numeroComparacion != 4 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_RECHAZADOS" ] && [ $numeroComparacion != 5 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_PROCESADOS" ] && [ $numeroComparacion != 6 ] ; then
                InstallLog"Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
            if [ "$GRUPO/$nombre" = "$DIR_SALIDA" ] && [ $numeroComparacion != 7 ] ; then
                InstallLog "Ya existe un directorio con ese nombre. Ingrese otro nombre." "A"
                res=0
            fi
        fi
        if [ $res = 0 ] ; then
            res=1
        else
            salir=1
        fi
    done
}


iniciarInstall(){

	if [ ! -e "$GRUPO/conf" ] ; then
		mkdir "$GRUPO/conf"
		mkdir "$GRUPO/conf/log"
		
		InstallLog "Se crea directorio $GRUPO/conf" "I"
		InstallLog "Se crea directorio $GRUPO/conf/log" "I"
		InstallLog "Se ha generado el log de instalacion: $GRUPO/conf/log/instalacion.log" "I"
	fi

	if [ ! -e "$GRUPO/conf/log" ] ; then
		mkdir "$GRUPO/conf/log"
		InstallLog "Se crea directorio $GRUPO/conf/log" "I"
		InstallLog "Se ha generado el log de instalacion: $GRUPO/conf/log/instalacion.log" "I"
	fi 

}


imprimirFinal(){
	InstallLog "TP SO7508 Segundo Cuatrimestre 2019. Copyright © Grupo 03" "I"
	while read -r linea
	do 
		DIR_ROLE=$(echo $linea | cut -d"-" -f1)
		DIR_PATH=$(echo $linea | cut -d"-" -f2)

		if [ "$DIR_ROLE" = "FATHER_DIR" ] ; then
			InstallLog  "Directorio padre: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "CONF_DIR" ] ; then
			InstallLog "Ruta del directorio conf: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "LOG_DIR" ] ; then
			InstallLog "Ruta del directorio de los archivos log: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "MASTER_DIR" ] ; then
			InstallLog "Ruta de la carpeta de maestros: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "ARRIVALS_DIR" ] ; then
			InstallLog "Ruta de la carpeta de arribos: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "ACCEPTED_DIR" ] ; then
			InstallLog "Ruta de la carpeta de novedades aceptadas: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "REJECTED_DIR" ] ; then
			InstallLog "Ruta del directorio de rechazados: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "PROCESSED_DIR" ] ; then
			InstallLog "Ruta del directorio ya procesados: $DIR_PATH" "I"
		fi
		if [ "$DIR_ROLE" = "OUTPUT_DIR" ] ; then
			InstallLog "Ruta del directorio de salida: $DIR_PATH" "I"
		fi

	done < $GRUPO/conf/tpconfig.txt
}

instalar(){
	InstallLog "Se le pide al usuario el nombre de los directorios a crear" "I"
	res=1
	fin=0
	while [ $fin = 0 ]; do
		InstallLog "Se comienza con el ingreso de los nombres" "I"

		InstallLog "Ingrese un nombre para el directorio de ejecutables ($DIR_BINARIOS)" "I"
		numeroComparacion=1
		default=0
		verificarNombres
		if [ $default = 0 ] ; then 
			DIR_BINARIOS=$GRUPO/$nombre
		fi
		InstallLog "nombre elegido directorio archivos ejecutables:$DIR_BINARIOS" "I"

		InstallLog "Ingrese un nombre para el directorio de archivos maestros ($DIR_MAESTROS)" "I"
		numeroComparacion=2
		default=0
		verificarNombres
		if [ $default = 0 ] ; then 
			DIR_MAESTROS=$GRUPO/$nombre
		fi
		InstallLog "nombre elegido archivos maestros:$DIR_MAESTROS" "I"

		InstallLog "Ingrese un nombre para el directorio de arribo de novedades ($DIR_ARRIBO_NOVEDADES)" "I"
		numeroComparacion=3
		default=0
		verificarNombres
		if [ $default = 0 ] ; then 
			DIR_ARRIBO_NOVEDADES=$GRUPO/$nombre    
		fi
		InstallLog "Se ha ingresado el nombre para el directorio de arribo de novedades:$DIR_ARRIBO_NOVEDADES" "I"

		InstallLog "Ingrese un nombre para el directorio de novedades aceptadas ($DIRNOVEDADESACEPTADAS)" "I"
		numeroComparacion=4
		default=0
		verificarNombres
		if [ $default = 0 ] ; then 
			DIRNOVEDADESACEPTADAS=$GRUPO/$nombre
		fi
		InstallLog "Se ha ingresado el nombre para el directorio de novedades aceptadas :$DIRNOVEDADESACEPTADAS" "I"

		InstallLog "Ingrese un nombre para el directorio de archivos rechazados ($DIR_RECHAZADOS)" "I"
		numeroComparacion=5
		default=0
		verificarNombres
		if [ $default = 0 ] ; then 
			DIR_RECHAZADOS=$GRUPO/$nombre
		fi
		InstallLog "Se ha ingresado el nombre para el directorio de novedades rechazadas:$DIR_RECHAZADOS" "I"

		InstallLog "Ingrese un nombre para el directorio de novedades procesadas ($DIR_PROCESADOS)" "I"
		numeroComparacion=6
		default=0
		verificarNombres
		if [ $default = 0 ] ; then
			DIR_PROCESADOS=$GRUPO/$nombre
		fi
		InstallLog "Se ha ingresado el nombre para el directorio de archivos ya procesados:$DIR_PROCESADOS" "I"

		InstallLog "Ingrese un nombre para el directorio de archivos de salida ($DIR_SALIDA)" "I"
		numeroComparacion=7
		default=0
		verificarNombres
		if [ $default = 0 ] ; then
			DIR_SALIDA=$GRUPO/$nombre
		fi 
		InstallLog "Se ha ingresado el nombre para el directorio de archivos de salida:$DIR_SALIDA" "I"
		
		echo " "

		listarDirectorios
		
		InstallLog "Estado de la instalación: LISTA  " "I"
		InstallLog "¿Desea confirmar la instalación? (s/n): " "I"
		opcion="s"
		valida=0
		while [ $valida = 0 ]; do
			read opcion        
			if [ -z "$opcion" ]; then
				InstallLog "No ha ingresado ninguna opcion." "I"
			else
				InstallLog "Se ha ingresado la opción: $opcion" "I"
				if [ "$opcion" = 's' ] || [ "$opcion" = 'n' ] || [ "$opcion" = 'S' ] || [ "$opcion" = 'N' ] || [ "$opcion" = 'si' ] || [ "$opcion" = 'no' ] || [ "$opcion" = 'NO' ] || [ "$opcion" = 'SI' ] || [ "$opcion" = 'Si' ] || [ "$opcion" = 'No' ] ; then
					valida=1
				else
					InstallLog "La opción: $opcion no es valida. Ingrese una opción válida (s/n)" "A"
				fi
			fi
		done
	
		if [ $opcion = "s" ] || [ $opcion = "S" ] || [ $opcion = "si" ] || [ $opcion = "Si" ] || [ $opcion = "SI" ] ; then
			fin=1
		else
			InstallLog "No se ha confirmado la instalación"
			InstallLog "¿Desea continuar la instalación? (s/n)" "I"
			valida=0
			while [ $valida = 0 ]; do
				read opcion        
				if [ -z "$opcion" ]; then
					InstallLog "No ha ingresado ninguna opcion." "I"
				else
					InstallLog "Se ha ingresado la opción: $opcion" "I"
					if [ "$opcion" = 's' ] || [ "$opcion" = 'n' ] || [ "$opcion" = 'S' ] || [ "$opcion" = 'N' ] || [ "$opcion" = 'si' ] || [ "$opcion" = 'no' ] || [ "$opcion" = 'NO' ] || [ "$opcion" = 'SI' ] || [ "$opcion" = 'Si' ] || [ "$opcion" = 'No' ] ; then
						valida=1
					else
						InstallLog "La opción: $opcion no es valida. Ingrese una opción válida (s/n)" "A"
					fi
				fi
			done
			if [ $opcion = "n" ] || [ $opcion = "N" ] || [ $opcion = "no" ] || [ $opcion = "No" ] || [ $opcion = "NO" ] ; then
				res=0
				fin=1
			fi
		fi
	done
	
	if [ $res = 1 ] ; then
		
		escribirTPconfig

		mkdir "$DIR_BINARIOS"
		InstallLog "Se ha creado: $DIR_BINARIOS" "I"
		
		mkdir "$DIR_MAESTROS"
		InstallLog "Se ha creado: $DIR_MAESTROS" "I"
		
		mkdir "$DIR_ARRIBO_NOVEDADES"
		InstallLog "Se ha creado:$DIR_ARRIBO_NOVEDADES" "I"
		
		mkdir "$DIRNOVEDADESACEPTADAS"
		InstallLog "Se ha creado:$DIRNOVEDADESACEPTADAS" "I"
		
		mkdir "$DIR_RECHAZADOS"
		InstallLog "Se ha creado:$DIR_RECHAZADOS" "I"
		
		mkdir "$DIR_PROCESADOS"
		InstallLog "Se ha creado:$DIR_PROCESADOS" "I"

		mkdir "$DIR_SALIDA"
		InstallLog "Se ha creado:$DIR_SALIDA" "I"
	
		cp -r "$GRUPO/TP/comandos/"* "$DIR_BINARIOS"
		cp -r "$GRUPO/TP/maestros/"* "$DIR_MAESTROS"
		echo " "
		InstallLog "Se ha instalado exitosamente" "I"
	
	else
		InstallLog "Se Cancelo la instalacion" "A"
	fi
	
	imprimirFinal
}

tp_config_sano(){

	sano="$(grep MASTER_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archios maestros" "A"
		return 0
	fi
	sano="$(grep ACCEPTED_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archivos aceptados" "A"
		return 0
	fi
	sano="$(grep OUTPUT_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archivos de salida" "A"
		return 0
	fi
	sano="$(grep REJECTED_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archios rechazados" "A"
		echo 0
	fi
	sano="$(grep ARRIVALS_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archios de novedades" "A"
		return 0
	fi
	sano="$(grep CONF_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archivos de conf" "A"
		return 0
	fi

	sano="$(grep BIN_DIR "$GRUPO/conf/tpconfig.txt" -c)"
	if [ $sano = 0 ] ; then
		InstallLog "Falta en tpconfig.txt configuracion de directorio de archivos binarios" "A"
		return 0
	fi

	return 1
}

repararInstalacion(){
	while read -r line
	do 
		DIR_ROLE=$(echo $line | cut -d"-" -f1)
		DIR_PATH=$(echo $line | cut -d"-" -f2)
		
		if [ ! -e "$DIR_PATH" ] ; then
			if [ $DIR_ROLE = "BIN_DIR" ] ; then
				InstallLog "Se debe restaurar directorio de ejecutables $DIR_PATH" "I"
				InstallLog "Restaurando directorio de ejecutables: $DIR_PATH" "I"
				mkdir $DIR_PATH
				InstallLog "Se ha creado directorio para ejecutables: $DIR_PATH" "I"
				cp -r $GRUPO/TP/comandos/* "$DIR_PATH" 
				InstallLog "Se ha copiado: $GRUPO/TP/comandos/* a: $DIR_PATH" "I"
			elif [ $DIR_ROLE = "MASTER_DIR" ] ; then
				InstallLog "Se debe restaurar directorio de archivos maestros $DIR_PATH" "I"
				InstallLog "Restaurando directorio de archivos maestros: $DIR_PATH" "I"
				mkdir $DIR_PATH
				InstallLog "Se ha creado directorio para maestros" "I"
				cp $GRUPO/TP/maestros/* "$DIR_PATH"
				InstallLog "Se ha copiado: $GRUPO/TP/maestros/* a: $DIR_PATH" "I"
			else 
				InstallLog "Se debe restaurar directorio: $DIR_PATH" "I"
				mkdir "$DIR_PATH"
				InstallLog "se ha creado directorio: $DIR_PATH" "I"
			fi
		else
			if [ $DIR_ROLE = "MASTER_DIR" ] ; then
				if [ ! -e "$DIR_PATH/CODIGOSISO8583.txt" ] ; then
					cp $GRUPO/TP/maestros/CODIGOSISO8583.txt "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/maestros/CODIGOSISO8583.txt a: $DIR_PATH" "I"
					res=0
				fi
			fi
			if [ $DIR_ROLE = "BIN_DIR" ] ; then
				if [ ! -e "$DIR_PATH/init.sh" ] ; then
					cp $GRUPO/TP/comandos/init.sh "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/comandos/init.sh a: $DIR_PATH" "I"
				fi
				if [ ! -e "$DIR_PATH/process.sh" ] ; then
					cp $GRUPO/TP/comandos/process.sh "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/comandos/process.sh a: $DIR_PATH" "I"
				fi
				if [ ! -e "$DIR_PATH/start.sh" ] ; then
					cp $GRUPO/TP/comandos/start.sh "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/comandos/start.sh a: $DIR_PATH" "I"
				fi
				if [ ! -e "$DIR_PATH/stop.sh" ] ; then
					cp $GRUPO/TP/comandos/stop.sh "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/comandos/stop.sh a: $DIR_PATH" "I"
				fi

				if [ ! -d "$DIR_PATH/shell" ] ; then
					mkdir "$DIR_PATH/shell"
					InstallLog "Se ha creado el directorio $DIR_PATH/shell" "I"
				fi
				if [ ! -e "$DIR_PATH/shell/log.sh" ] ; then
					InstallLog "Se restaurará shell/log.sh" "I"
					cp $GRUPO/TP/comandos/stop.sh "$DIR_PATH"
					InstallLog "Se ha copiado: $GRUPO/TP/comandos/shell/log.sh a: $DIR_PATH" "I"
				fi
			fi
		fi
	done < $GRUPO/conf/tpconfig.txt
	InstallLog "Se ha reparado la instalación en base a $GRUPO/conf/tpconfig.txt" "I"   
	InstallLog "Instalación reparada" "I"

}


repairTest(){
	missing_install_log=0
	need_repair=1
	if [ ! -d "$GRUPO/conf/log" ] ; then
		missing_install_log=1
		mkdir "$GRUPO/conf/log"
	fi
	
	InstallLog "Se ha encontrado un archivo de configuración de instalación previa" "I"
	
	if [ $missing_install_log = 1 ] ; then
		InstallLog "No se encontró archivo de log de instalación previa" "A"
		InstallLog "Se ha creado log de instalación $GRUPO/conf/log/instalacion.log" "I"
	fi

	InstallLog "Se realizará test del estado de la instalación anterior" "I"
	
	while read -r linea
	do 
		DIR_ROLE=$(echo $linea | cut -d"-" -f1)
		RUTA=$(echo $linea | cut -d"-" -f2)
		if [ ! -e "$RUTA" ] ; then
			InstallLog "Test de reparación: No se ha encontrado el directorio $RUTA" "A"
			InstallLog "Reparación necesaria" "A"
			need_repair=0
		else
			if [ "$DIR_ROLE" = "BIN_DIR" ] ; then
				if [ ! -e "$RUTA/init.sh" ] ; then
					InstallLog "Test de reparación: Falta archivo ejecutable init.sh" "A"
					InstallLog "Reparación necesaria" "A"
					need_repair=0
				fi
				if [ ! -e "$RUTA/process.sh" ] ; then
					InstallLog "Test de reparación: Debe restaurarse el ejecutable process.sh" "A"
					InstallLog "Reparación necesaria" "A"
					need_repair=0
				fi
				if [ ! -e "$RUTA/start.sh" ] ; then
					InstallLog "Test de reparación: Debe restaurarse el ejecutable start.sh" "A"
					InstallLog "Reparación necesaria" "A"
					need_repair=0
				fi
				if [ ! -e "$RUTA/stop.sh" ] ; then
					InstallLog "Test de reparación: Falta archivo ejecutable stop.sh" "A"
					InstallLog "Reparación necesaria" "A"
					need_repair=0
				fi
			fi
	
			if [ "$DIR_ROLE" = "MASTER_DIR" ] ; then
				if [ ! -e "$RUTA/CODIGOSISO8583.txt" ] ; then
					InstallLog "Test de reparación: Falta archivo CODIGOSISO8583.txt" "A"
					InstallLog "Reparación necesaria" "A"
					need_repair=0
				fi
			fi
		fi
		
	done < $GRUPO/conf/tpconfig.txt

	if [ $need_repair = 0 ] ; then
		return 1
	else 
		return 0
	fi
}

paquete_original_sano(){ 
	if [ ! -e "$GRUPO/TP" ] ; then
		status=0
		InstallLog "Falta el directorio del paquete original $GRUPO/TP" "A"
	else
		if [ ! -e "$GRUPO/TP/comandos" ] ; then
			status=0
			InstallLog "Falta el directorio del paquete original $GRUPO/TP/comandos" "A"
		else
			if [ ! -f "$GRUPO/TP/comandos/init.sh" ] ; then
				status=0
				InstallLog "Falta el ejecutable del paquete original init.sh" "A"
			fi
			if [ ! -f "$GRUPO/TP/comandos/process.sh" ] ; then
				status=0
				InstallLog "Falta el ejecutable del paquete original process.sh" "A"

			fi
			if [ ! -f "$GRUPO/TP/comandos/start.sh" ] ; then
				status=0
				InstallLog "Falta el ejecutable del paquete original start.sh" "A"
			fi
			if [ ! -f "$GRUPO/TP/comandos/stop.sh" ] ; then
				status=0
				InstallLog "Falta el ejecutable del paquete original stop.sh" "A"
			fi
		fi
		if [ ! -e "$GRUPO/TP/maestros" ] ; then
			status=0
			InstallLog "Falta el directorio del paquete original $GRUPO/TP/maestros" "A"
		else 
			if [ ! -e "$GRUPO/TP/maestros/CODIGOSISO8583.txt" ] ; then
				InstallLog "Falta el archivo maestro del paquete original $GRUPO/TP/CODIGOSISO8583.txt" "A"
				status=0
			fi
		fi
	fi
	if [ "$status" = 0 ] ; then 
		return 0
	else 
		return 1
	fi

}


main(){

	iniciarInstall
	
	LOG_DIR="./conf/log"

	export LOG_DIR="./conf/log"

	if [ "$NUM_ARGS" -ge 2 ] ; then
		InstallLog "Cantidad ingresada de argumentos es inválida" "A"
		InstallLog "Argumentos permitidos: -r" "I"
		exit
	elif [ "$NUM_ARGS" -eq 1 ] ; then
		if [ "$OPCION" = "-r" ] ; then
			InstallLog "Se ha ingresado la opción de reparación '-r'" "I"
			if [ -f "$GRUPO/conf/tpconfig.txt" ] ; then
				InstallLog "Se ha detectado una instalación previa" "A"
				tp_config_sano
				if [ $? = 0 ] ; then
					InstallLog "El archivo tpconfig.txt se ecuentra corrupto" "E"
					InstallLog "No se puede reparar" "A"
					InstallLog "Saliendo del proceso de instalacion" "I"
					exit
				fi
				repairTest
				if [ $? = 1 ] ; then 
					InstallLog "Se debe reparar la instalación." "A"
					paquete_original_sano
					if [ $? = 1 ] ; then 
						repararInstalacion
					else
						InstallLog "No puede repararse la instalación. Paquete original corrupto." "A"
						InstallLog "Debe descargar de nuevo el paquete de instalación" "A"
						InstallLog "Saliendo del proceso de instalación" "I"
						exit
					fi
				else 
					InstallLog "La instalación existente se encuentra en buen estado" "I"
					InstallLog "No hay necesidad de reparar la instalación" "I"
				fi
			fi
		else
			InstallLog "Se ha ingresado una opción inválida: $1" "E"
		fi
	else 
		if [ -f "$GRUPO/conf/tpconfig.txt" ] ; then
			InstallLog "Se ha detectado una instalación previa" "A"
			tp_config_sano
			if [ $? = 0 ] ; then
				InstallLog "El archivo tpconfig.txt se ecuentra corrupto" "E"
				InstallLog "No se puede reparar" "A"
				InstallLog "Saliendo del proceso de instalacion" "I"
				exit
			fi
			repairTest
			if [ $? = 1 ] ; then 
				InstallLog "Se debe reparar la instalación." "A"
				InstallLog "Para repararse debe instalar de vuelta con la opción '-r'" "A"
				InstallLog "Saliendo de proceso de instalación" "I"
				exit
			else 
				InstallLog "La instalación existente se encuentra en buen estado" "I"
				InstallLog "No hay necesidad de reparar la instalación" "I"
				imprimirFinal
				InstallLog "Saliendo de proceso de instalación" "I"
			fi
		else
			paquete_original_sano
			if [ $? = 1 ] ; then 
				instalar
			else
				InstallLog "No se puede realizar la instalación. Paquete original corrupto." "E"
				InstallLog "Debe volver a descargar el paquete original e intentar nuevamente" "E"
			fi
		fi
	fi
}

main
