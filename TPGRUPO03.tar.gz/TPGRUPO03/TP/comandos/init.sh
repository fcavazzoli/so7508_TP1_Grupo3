logger()
{
  sh logger/logger.sh "$1" "$2" "init.sh"
}

# Inicio el proceso de Inicializacion

HEALTHY_ENV=1

if [ ! -f "logger/logger.sh" ]; then
  echo "No se encuentra la libreria de log."
  HEALTHY_ENV=0
fi

logger "Proceso de Inicializacion" "I"

if [ ! -d "../conf" ]; then
  logger "No existe el directorio reservado 'conf'." "E"
  HEALTHY_ENV=0
fi

if [ ! -f "../conf/tpconfig.txt" ]; then
  logger "No existe el archivo de configuracion 'tpconfig.txt'." "E"
  HEALTHY_ENV=0
fi


# Se setean las variables de entorno
while IFS= read -r var
do
  VARIABLE=$(echo $var | cut -d"-" -f1)
  VALUE=$(echo $var | sed "s/\(^[^-]*-\)\(.*$\)/\2/")

  # Me fijo si el directorio existe (pagina 6)
  if [ ! -d "$VALUE" ]; then
    logger "El directorio $VALUE no existe." "E"
    HEALTHY_ENV=0
  fi
  logger "Seteo variables $VARIABLE = $VALUE" "I"
  export "$VARIABLE"="$VALUE"

done < "../conf/tpconfig.txt"

if [ ! -z "$MASTER_DIR" ]; then
  if [ ! -f "$MASTER_DIR/CODIGOSISO8583.txt" ]; then
    logger "No existe el archivo maestro de 'CODIGOSISO8583.txt'." "E"
    HEALTHY_ENV=0
  fi
fi



if [ $HEALTHY_ENV -eq 0 ]; then
  logger "No se puede inicializar el sistema." "E"
  logger "Debe reinstalar la aplicacion ejecutando el comando: " "I"
  logger "  sh install.sh -r" "I"
  exit
fi


# Obtengo la lista de procesos para saber si ya esta corriendo
PSAG="$(ps ag)"
RUNNING_PROCESSES=$(echo "$PSAG" | grep -c 'process.sh')

logger "Cantidad de procesos corriendo $RUNNING_PROCESSES" "I"

export HEALTHY_ENV="$HEALTHY_ENV"

if [ $RUNNING_PROCESSES -eq 0 ]; then    
    logger "El proceso NO esta corriendo." "I"
    . ./start.sh    
else
    logger "El proceso ya se encuentra corriendo." "A"
fi

logger "Saliendo del proceso init.sh" "I"

