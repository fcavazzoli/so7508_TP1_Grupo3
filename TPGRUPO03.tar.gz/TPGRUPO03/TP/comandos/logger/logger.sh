MESSAGE=$1
TYPE=$2
pidName=$3


if [ "$TYPE" = "I" ]; then
  TYPE="INFO"
elif [ "$TYPE" = "A" ]; then
  TYPE="ATEN"
else
  TYPE="ERROR"
fi

format_date=$(date +"%Y.%m.%d")


MESSAGE=$format_date-$USER-$pidName-$TYPE-$MESSAGE

# Como esta ruta
if [ -z $PROCESS_LOG ]; then
  PROCESS_LOG="../conf/log"
fi

echo $MESSAGE
echo $MESSAGE >> "$PROCESS_LOG/$pidName.log"
